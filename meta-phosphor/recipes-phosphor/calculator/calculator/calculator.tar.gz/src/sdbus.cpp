#include <sdbusplus/sdbus.hpp>

namespace sdbusplus
{
SdBusImpl sdbus_impl;
}
